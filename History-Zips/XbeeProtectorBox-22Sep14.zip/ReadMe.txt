Product: Xbee Protector Box, September 2014

Designer: Simon Kirkby

Support:  http://forums.obrary.com/category/designs/xbee-protector-box

Distributed by:  Obrary, Inc.  http://obrary.com.  Obrary is a marketplace of products collaboratively designed by the community. These products can be produced by anyone, amateur or professional manufacturer, wherever economically or locally practical.

Description:
The Xbee Protector Box is designed to be printed on a Laser Cutter from acrylic.